﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Area administrativa</title>
<link href="estilo_adm.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="box">
 
  <div id="topo">
    <img src="imgadmin/topo_admin.gif" border="0" usemap="#Map" />
    <map name="Map" id="Map">
    <area shape="circle" coords="111,97,104" href="admin.php" />
  </map>
  </div><!--topo-->
  <div id="menu">
<?php include "menu_adm.php" ?>
</div><!--menu-->