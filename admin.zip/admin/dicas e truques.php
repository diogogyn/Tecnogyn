<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Area administrativa</title>
<link href="estilo_adm.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="box">
 
  <div id="topo">
    <img src="imgadmin/topo_admin.gif" border="0" usemap="#Map" />
    <map name="Map" id="Map">
    <area shape="circle" coords="111,97,104" href="admin.php" />
  </map>
  </div><!--topo-->
  <div id="menu">
<?php include "menu_adm.php" ?>
</div><!--menu-->
  
<div id="content">

<div id="conteudo">
	Dicas e truques
do tecnogyn

Dicas e truques do tecnogyn ficara nesta pagina

Mas por enquanto este site esta em construção. mas você pode visitar nosso outo site para isso clique aqui
<hr />


</div><!--conteudo-->
<div id="lateral"> <a href="http://tecnogyn.wufoo.com/forms/assinatura-de-newsletter-gratuita/" target="_blank"><img src="imgs/newsletter_big.jpg" /></a>
<hr />

<h1>Comunicados:</h1>
<p>Não há nenhum comunicado</p>

</div><!--lateral-->
<div id="divclear">
</div><!--divclear-->

</div><!--content-->

</div><!--box-->

</body>
<div id="footer">
 <div id="copy">
    <strong>Tecnogyn</strong> - <strong>email:</strong> tecnogyn100@gmail.com<br />
    Goiânia/GO<br />
    &copy; 2008 - <?php echo date('Y') ?> Tecnogyn - O mundo em suas mãos - Todos os direitos reservados
  
  </div><!--copy-->
</div><!--footer-->

</html>