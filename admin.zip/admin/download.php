<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Area administrativa</title>
<link href="estilo_adm.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="box">
 
  <div id="topo">
    <img src="imgadmin/topo_admin.gif" border="0" usemap="#Map" />
    <map name="Map" id="Map">
    <area shape="circle" coords="111,97,104" href="admin.php" />
  </map>
  </div><!--topo-->
  <div id="menu">
<?php include "menu_adm.php" ?>
</div><!--menu-->

<div id="content">

<div id="conteudo">
	Esta pagina esta reservada para os administradores do site tecnogyn. A apartir daqui serão feitas e acrescentados os conteudo no site ao decorrer do tempo. Aguarde este site esta em construção, para melhor atende-lo, logo você podera desfrutar dos recrusos oferecidos pelo Tecnogyn, O mundo em sua mãos!!!
    Aproveite e visite o onsso antigo site:www.tecnogyn.webnode.com
    e não esqueça de mandar seu comentario!!!
<hr />    
    
    <h1>Promoção Merece um clique!</h1>
    A partir de agora o Tecnogyn, esta com um novo quadro chamado, Merece um clique. Todas as semana um ou mais site(s) sera escolhido e analizado pelo tecnogyn, falando um pouco sobre ele.

Sera analizado todos os tipos de sites (exceto os com conteudo proibido para maiores de 18 anos) além dos sites parceiros do tecnogyn. Então, se você tem um site e quer que falemos dele em nosso site,preencha o formulario de parceria ou mande um email para tecnogyn100@gmail.com. Confirme sua parecria conosco e aguarde nossa resposta, e futuramente lançaremos um artigo sobre seu site!
<hr />


</div><!--conteudo-->
<div id="lateral"> <a href="http://tecnogyn.wufoo.com/forms/assinatura-de-newsletter-gratuita/" target="_blank"><img src="imgs/newsletter_big.jpg" /></a>
<hr />

<h1>Comunicados:</h1>
<p>Não há nenhum comunicado</p>

</div><!--lateral-->
<div id="divclear">
</div><!--divclear-->

</div><!--content-->

</div><!--box-->

</body>
<div id="footer">
 <div id="copy">
    <strong>Tecnogyn</strong> - <strong>email:</strong> tecnogyn100@gmail.com<br />
    Goiânia/GO<br />
    &copy; 2008 - <?php echo date('Y') ?> Tecnogyn - O mundo em suas mãos - Todos os direitos reservados
  
  </div><!--copy-->
</div><!--footer-->

</html>