﻿<a href="admin.php">INICIO</a>
  <img src="imgadmin/separador.png" />
  <a href="noticias.php">NOTICIAS</a>
  <img src="imgadmin/separador.png" />
  <a href="dicas e truques.php">DICAS E TRUQUES</a>
  <img src="imgadmin/separador.png" />
  <a href="download.php">DOWNLOADS</a>
  <img src="imgadmin/separador.png" />
  <a href="videos.php">VIDEOS</a>
  <img src="imgadmin/separador.png" />
  <a href="contato.php">CONTATO</a>
  <img src="imgadmin/separador.png" />
  <a href="cadastro.php" target="_blank">CADASTRAR MEMBROS</a>
  <img src="imgadmin/separador.png" />
  <a href="index.php">SAIR</a>